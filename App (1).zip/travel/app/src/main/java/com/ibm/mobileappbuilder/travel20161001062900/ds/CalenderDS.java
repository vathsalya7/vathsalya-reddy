

package com.ibm.mobileappbuilder.travel20161001062900.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "CalenderDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class CalenderDS extends AppNowDatasource<CalenderDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private CalenderDSService service;

    public static CalenderDS getInstance(SearchOptions searchOptions){
        return new CalenderDS(searchOptions);
    }

    private CalenderDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = CalenderDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<CalenderDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<CalenderDSItem>>() {
                @Override
                public void onSuccess(List<CalenderDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new CalenderDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getCalenderDSItemById(id, new Callback<CalenderDSItem>() {
                @Override
                public void success(CalenderDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<CalenderDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<CalenderDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryCalenderDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<CalenderDSItem>>() {
            @Override
            public void success(List<CalenderDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{null};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(CalenderDSItem item, Listener<CalenderDSItem> listener) {
                          service.getServiceProxy().createCalenderDSItem(item, callbackFor(listener));
          }

    private Callback<CalenderDSItem> callbackFor(final Listener<CalenderDSItem> listener) {
      return new Callback<CalenderDSItem>() {
          @Override
          public void success(CalenderDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(CalenderDSItem item, Listener<CalenderDSItem> listener) {
                          service.getServiceProxy().updateCalenderDSItem(item.getIdentifiableId(), item, callbackFor(listener));
          }

    @Override
    public void deleteItem(CalenderDSItem item, final Listener<CalenderDSItem> listener) {
                service.getServiceProxy().deleteCalenderDSItemById(item.getIdentifiableId(), new Callback<CalenderDSItem>() {
            @Override
            public void success(CalenderDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<CalenderDSItem> items, final Listener<CalenderDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<CalenderDSItem>>() {
            @Override
            public void success(List<CalenderDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<CalenderDSItem> items){
        List<String> ids = new ArrayList<>();
        for(CalenderDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

