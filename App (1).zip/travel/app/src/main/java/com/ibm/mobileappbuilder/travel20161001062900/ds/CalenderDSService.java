
package com.ibm.mobileappbuilder.travel20161001062900.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.travel20161001062900.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "CalenderDSService" REST Service implementation
 */
public class CalenderDSService extends RestService<CalenderDSServiceRest>{

    public static CalenderDSService getInstance(){
          return new CalenderDSService();
    }

    private CalenderDSService() {
        super(CalenderDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "GD0gIwms";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef58409d17e00300d4d1e8",
                path,
                "apikey=GD0gIwms");
    }

}

