
package com.ibm.mobileappbuilder.travel20161001062900.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface CalenderDSServiceRest{

	@GET("/app/57ef58409d17e00300d4d1e8/r/calenderDS")
	void queryCalenderDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<CalenderDSItem>> cb);

	@GET("/app/57ef58409d17e00300d4d1e8/r/calenderDS/{id}")
	void getCalenderDSItemById(@Path("id") String id, Callback<CalenderDSItem> cb);

	@DELETE("/app/57ef58409d17e00300d4d1e8/r/calenderDS/{id}")
  void deleteCalenderDSItemById(@Path("id") String id, Callback<CalenderDSItem> cb);

  @POST("/app/57ef58409d17e00300d4d1e8/r/calenderDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<CalenderDSItem>> cb);

  @POST("/app/57ef58409d17e00300d4d1e8/r/calenderDS")
  void createCalenderDSItem(@Body CalenderDSItem item, Callback<CalenderDSItem> cb);

  @PUT("/app/57ef58409d17e00300d4d1e8/r/calenderDS/{id}")
  void updateCalenderDSItem(@Path("id") String id, @Body CalenderDSItem item, Callback<CalenderDSItem> cb);

  @GET("/app/57ef58409d17e00300d4d1e8/r/calenderDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

