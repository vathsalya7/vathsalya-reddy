
package com.ibm.mobileappbuilder.travel20161001062900.ds;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.Uri;
import android.net.Uri;
import android.net.Uri;
import android.net.Uri;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ClothsDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("jackets") public String jackets;
    @SerializedName("shirts") public String shirts;
    @SerializedName("shoes") public String shoes;
    @SerializedName("assesories") public String assesories;
    @SerializedName("pants") public String pants;
    @SerializedName("bags") public String bags;
    @SerializedName("id") public String id;
    @SerializedName("jacketsUri") public transient Uri jacketsUri;
    @SerializedName("shirtsUri") public transient Uri shirtsUri;
    @SerializedName("shoesUri") public transient Uri shoesUri;
    @SerializedName("assesoriesUri") public transient Uri assesoriesUri;
    @SerializedName("pantsUri") public transient Uri pantsUri;
    @SerializedName("bagsUri") public transient Uri bagsUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(jackets);
        dest.writeString(shirts);
        dest.writeString(shoes);
        dest.writeString(assesories);
        dest.writeString(pants);
        dest.writeString(bags);
        dest.writeString(id);
    }

    public static final Creator<ClothsDSItem> CREATOR = new Creator<ClothsDSItem>() {
        @Override
        public ClothsDSItem createFromParcel(Parcel in) {
            ClothsDSItem item = new ClothsDSItem();

            item.jackets = in.readString();
            item.shirts = in.readString();
            item.shoes = in.readString();
            item.assesories = in.readString();
            item.pants = in.readString();
            item.bags = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public ClothsDSItem[] newArray(int size) {
            return new ClothsDSItem[size];
        }
    };

}


