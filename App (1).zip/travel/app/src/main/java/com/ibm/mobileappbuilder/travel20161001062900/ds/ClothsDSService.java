
package com.ibm.mobileappbuilder.travel20161001062900.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.travel20161001062900.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "ClothsDSService" REST Service implementation
 */
public class ClothsDSService extends RestService<ClothsDSServiceRest>{

    public static ClothsDSService getInstance(){
          return new ClothsDSService();
    }

    private ClothsDSService() {
        super(ClothsDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "GD0gIwms";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef58409d17e00300d4d1e8",
                path,
                "apikey=GD0gIwms");
    }

}

