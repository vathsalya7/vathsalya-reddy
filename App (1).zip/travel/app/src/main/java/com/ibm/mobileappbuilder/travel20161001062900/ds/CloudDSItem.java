
package com.ibm.mobileappbuilder.travel20161001062900.ds;
import ibmmobileappbuilder.ds.restds.GeoPoint;
import ibmmobileappbuilder.ds.restds.GeoPoint;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class CloudDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("source") public GeoPoint source;
    @SerializedName("destination") public GeoPoint destination;
    @SerializedName("id") public String id;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeDoubleArray(source != null  && source.coordinates.length != 0 ? source.coordinates : null);
        dest.writeDoubleArray(destination != null  && destination.coordinates.length != 0 ? destination.coordinates : null);
        dest.writeString(id);
    }

    public static final Creator<CloudDSItem> CREATOR = new Creator<CloudDSItem>() {
        @Override
        public CloudDSItem createFromParcel(Parcel in) {
            CloudDSItem item = new CloudDSItem();

            double[] source_coords = in.createDoubleArray();
            if (source_coords != null)
                item.source = new GeoPoint(source_coords);
            double[] destination_coords = in.createDoubleArray();
            if (destination_coords != null)
                item.destination = new GeoPoint(destination_coords);
            item.id = in.readString();
            return item;
        }

        @Override
        public CloudDSItem[] newArray(int size) {
            return new CloudDSItem[size];
        }
    };

}


