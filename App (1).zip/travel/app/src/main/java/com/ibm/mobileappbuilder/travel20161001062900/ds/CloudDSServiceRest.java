
package com.ibm.mobileappbuilder.travel20161001062900.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;

public interface CloudDSServiceRest{

	@GET("/app/57ef58409d17e00300d4d1e8/r/cloudDS")
	void queryCloudDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<CloudDSItem>> cb);

	@GET("/app/57ef58409d17e00300d4d1e8/r/cloudDS/{id}")
	void getCloudDSItemById(@Path("id") String id, Callback<CloudDSItem> cb);

	@DELETE("/app/57ef58409d17e00300d4d1e8/r/cloudDS/{id}")
  void deleteCloudDSItemById(@Path("id") String id, Callback<CloudDSItem> cb);

  @POST("/app/57ef58409d17e00300d4d1e8/r/cloudDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<CloudDSItem>> cb);

  @POST("/app/57ef58409d17e00300d4d1e8/r/cloudDS")
  void createCloudDSItem(@Body CloudDSItem item, Callback<CloudDSItem> cb);

  @PUT("/app/57ef58409d17e00300d4d1e8/r/cloudDS/{id}")
  void updateCloudDSItem(@Path("id") String id, @Body CloudDSItem item, Callback<CloudDSItem> cb);

  @GET("/app/57ef58409d17e00300d4d1e8/r/cloudDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
}

