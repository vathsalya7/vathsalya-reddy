

package com.ibm.mobileappbuilder.travel20161001062900.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "ModeDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class ModeDS extends AppNowDatasource<ModeDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private ModeDSService service;

    public static ModeDS getInstance(SearchOptions searchOptions){
        return new ModeDS(searchOptions);
    }

    private ModeDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = ModeDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<ModeDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<ModeDSItem>>() {
                @Override
                public void onSuccess(List<ModeDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new ModeDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getModeDSItemById(id, new Callback<ModeDSItem>() {
                @Override
                public void success(ModeDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<ModeDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<ModeDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryModeDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<ModeDSItem>>() {
            @Override
            public void success(List<ModeDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{null};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(ModeDSItem item, Listener<ModeDSItem> listener) {
                    
        if(item.flightUri != null ||
        item.trainUri != null ||
        item.busUri != null ||
        item.carUri != null){
            service.getServiceProxy().createModeDSItem(item,
                TypedByteArrayUtils.fromUri(item.flightUri),
                TypedByteArrayUtils.fromUri(item.trainUri),
                TypedByteArrayUtils.fromUri(item.busUri),
                TypedByteArrayUtils.fromUri(item.carUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createModeDSItem(item, callbackFor(listener));
        
    }

    private Callback<ModeDSItem> callbackFor(final Listener<ModeDSItem> listener) {
      return new Callback<ModeDSItem>() {
          @Override
          public void success(ModeDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(ModeDSItem item, Listener<ModeDSItem> listener) {
                    
        if(item.flightUri != null ||
        item.trainUri != null ||
        item.busUri != null ||
        item.carUri != null){
            service.getServiceProxy().updateModeDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.flightUri),
                TypedByteArrayUtils.fromUri(item.trainUri),
                TypedByteArrayUtils.fromUri(item.busUri),
                TypedByteArrayUtils.fromUri(item.carUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateModeDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(ModeDSItem item, final Listener<ModeDSItem> listener) {
                service.getServiceProxy().deleteModeDSItemById(item.getIdentifiableId(), new Callback<ModeDSItem>() {
            @Override
            public void success(ModeDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<ModeDSItem> items, final Listener<ModeDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<ModeDSItem>>() {
            @Override
            public void success(List<ModeDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<ModeDSItem> items){
        List<String> ids = new ArrayList<>();
        for(ModeDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

