
package com.ibm.mobileappbuilder.travel20161001062900.ds;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.Uri;
import android.net.Uri;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ModeDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("flight") public String flight;
    @SerializedName("train") public String train;
    @SerializedName("bus") public String bus;
    @SerializedName("car") public String car;
    @SerializedName("id") public String id;
    @SerializedName("flightUri") public transient Uri flightUri;
    @SerializedName("trainUri") public transient Uri trainUri;
    @SerializedName("busUri") public transient Uri busUri;
    @SerializedName("carUri") public transient Uri carUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(flight);
        dest.writeString(train);
        dest.writeString(bus);
        dest.writeString(car);
        dest.writeString(id);
    }

    public static final Creator<ModeDSItem> CREATOR = new Creator<ModeDSItem>() {
        @Override
        public ModeDSItem createFromParcel(Parcel in) {
            ModeDSItem item = new ModeDSItem();

            item.flight = in.readString();
            item.train = in.readString();
            item.bus = in.readString();
            item.car = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public ModeDSItem[] newArray(int size) {
            return new ModeDSItem[size];
        }
    };

}


