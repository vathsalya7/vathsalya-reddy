
package com.ibm.mobileappbuilder.travel20161001062900.presenters;

import com.ibm.mobileappbuilder.travel20161001062900.R;
import com.ibm.mobileappbuilder.travel20161001062900.ds.ClothsDSItem;

import java.util.List;

import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.mvp.presenter.BasePresenter;
import ibmmobileappbuilder.mvp.presenter.ListCrudPresenter;
import ibmmobileappbuilder.mvp.view.CrudListView;

public class ClothsPresenter extends BasePresenter implements ListCrudPresenter<ClothsDSItem>,
      Datasource.Listener<ClothsDSItem>{

    private final CrudDatasource<ClothsDSItem> crudDatasource;
    private final CrudListView<ClothsDSItem> view;

    public ClothsPresenter(CrudDatasource<ClothsDSItem> crudDatasource,
                                         CrudListView<ClothsDSItem> view) {
       this.crudDatasource = crudDatasource;
       this.view = view;
    }

    @Override
    public void deleteItem(ClothsDSItem item) {
        crudDatasource.deleteItem(item, this);
    }

    @Override
    public void deleteItems(List<ClothsDSItem> items) {
        crudDatasource.deleteItems(items, this);
    }

    @Override
    public void addForm() {
        view.showAdd();
    }

    @Override
    public void editForm(ClothsDSItem item, int position) {
        view.showEdit(item, position);
    }

    @Override
    public void detail(ClothsDSItem item, int position) {
        view.showDetail(item, position);
    }

    @Override
    public void onSuccess(ClothsDSItem item) {
                view.showMessage(R.string.items_deleted);
        view.refresh();
    }

    @Override
    public void onFailure(Exception e) {
        view.showMessage(R.string.error_data_generic);
    }

}

