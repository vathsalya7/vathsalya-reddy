
package com.ibm.mobileappbuilder.travel20161001062900.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.ibm.mobileappbuilder.travel20161001062900.R;
import ibmmobileappbuilder.ds.Datasource;
import android.text.format.DateFormat;
import android.widget.TextView;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.travel20161001062900.ds.CalenderDSItem;
import com.ibm.mobileappbuilder.travel20161001062900.ds.CalenderDS;

public class CalenderFragment extends ibmmobileappbuilder.ui.DetailFragment<CalenderDSItem>  {

    private Datasource<CalenderDSItem> datasource;
    private SearchOptions searchOptions;

    public static CalenderFragment newInstance(Bundle args){
        CalenderFragment card = new CalenderFragment();
        card.setArguments(args);

        return card;
    }

    public CalenderFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            searchOptions = SearchOptions.Builder.searchOptions().build();
    }

    @Override
    public Datasource getDatasource() {
      if (datasource != null) {
          return datasource;
      }
          datasource = CalenderDS.getInstance(searchOptions);
          return datasource;
    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.calender_custom;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final CalenderDSItem item, View view) {
        if (item.date != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(DateFormat.getMediumDateFormat(getActivity()).format(item.date));
            
        }
    }

    @Override
    protected void onShow(CalenderDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("calender");
    }

}

