
package com.ibm.mobileappbuilder.travel20161001062900.ui;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import com.ibm.mobileappbuilder.travel20161001062900.ds.ClothsDSItem;
import com.ibm.mobileappbuilder.travel20161001062900.ds.ClothsDSService;
import com.ibm.mobileappbuilder.travel20161001062900.presenters.ClothsFormPresenter;
import com.ibm.mobileappbuilder.travel20161001062900.R;
import ibmmobileappbuilder.ui.FormFragment;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.views.ImagePicker;
import java.io.IOException;
import java.io.File;

import static android.net.Uri.fromFile;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.CrudDatasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.travel20161001062900.ds.ClothsDSItem;
import com.ibm.mobileappbuilder.travel20161001062900.ds.ClothsDS;

public class ClothsDSItemFormFragment extends FormFragment<ClothsDSItem> {

    private CrudDatasource<ClothsDSItem> datasource;

    public static ClothsDSItemFormFragment newInstance(Bundle args){
        ClothsDSItemFormFragment fr = new ClothsDSItemFormFragment();
        fr.setArguments(args);

        return fr;
    }

    public ClothsDSItemFormFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        // the presenter for this view
        setPresenter(new ClothsFormPresenter(
                (CrudDatasource) getDatasource(),
                this));

            }

    @Override
    protected ClothsDSItem newItem() {
        return new ClothsDSItem();
    }

    private ClothsDSService getRestService(){
        return ClothsDSService.getInstance();
    }

    @Override
    protected int getLayout() {
        return R.layout.cloths_form;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ClothsDSItem item, View view) {
        
        bindImage(R.id.clothsds_jackets,
            item.jackets != null ?
                getRestService().getImageUrl(item.jackets) : null,
            0,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.jackets = null;
                    item.jacketsUri = null;
                    ((ImagePicker) getView().findViewById(R.id.clothsds_jackets)).clear();
                }
            }
        );
        
        
        bindImage(R.id.clothsds_shirts,
            item.shirts != null ?
                getRestService().getImageUrl(item.shirts) : null,
            1,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.shirts = null;
                    item.shirtsUri = null;
                    ((ImagePicker) getView().findViewById(R.id.clothsds_shirts)).clear();
                }
            }
        );
        
        
        bindImage(R.id.clothsds_shoes,
            item.shoes != null ?
                getRestService().getImageUrl(item.shoes) : null,
            2,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.shoes = null;
                    item.shoesUri = null;
                    ((ImagePicker) getView().findViewById(R.id.clothsds_shoes)).clear();
                }
            }
        );
        
        
        bindImage(R.id.clothsds_assesories,
            item.assesories != null ?
                getRestService().getImageUrl(item.assesories) : null,
            3,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.assesories = null;
                    item.assesoriesUri = null;
                    ((ImagePicker) getView().findViewById(R.id.clothsds_assesories)).clear();
                }
            }
        );
        
        
        bindImage(R.id.clothsds_pants,
            item.pants != null ?
                getRestService().getImageUrl(item.pants) : null,
            4,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.pants = null;
                    item.pantsUri = null;
                    ((ImagePicker) getView().findViewById(R.id.clothsds_pants)).clear();
                }
            }
        );
        
        
        bindImage(R.id.clothsds_bags,
            item.bags != null ?
                getRestService().getImageUrl(item.bags) : null,
            5,
            new ImagePicker.Callback(){
                @Override
                public void imageRemoved(){
                    item.bags = null;
                    item.bagsUri = null;
                    ((ImagePicker) getView().findViewById(R.id.clothsds_bags)).clear();
                }
            }
        );
        
    }

    @Override
    public Datasource<ClothsDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = ClothsDS.getInstance(new SearchOptions());
        return datasource;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == Activity.RESULT_OK) {
            ImagePicker picker = null;
            Uri imageUri = null;
            ClothsDSItem item = getItem();

            if((requestCode & ImagePicker.GALLERY_REQUEST_CODE) == ImagePicker.GALLERY_REQUEST_CODE) {
              imageUri = data.getData();
              switch (requestCode - ImagePicker.GALLERY_REQUEST_CODE) {
                        
                        case 0:   // jackets field
                            item.jacketsUri = imageUri;
                            item.jackets = "cid:jackets";
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_jackets);
                            break;
                        
                        
                        case 1:   // shirts field
                            item.shirtsUri = imageUri;
                            item.shirts = "cid:shirts";
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_shirts);
                            break;
                        
                        
                        case 2:   // shoes field
                            item.shoesUri = imageUri;
                            item.shoes = "cid:shoes";
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_shoes);
                            break;
                        
                        
                        case 3:   // assesories field
                            item.assesoriesUri = imageUri;
                            item.assesories = "cid:assesories";
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_assesories);
                            break;
                        
                        
                        case 4:   // pants field
                            item.pantsUri = imageUri;
                            item.pants = "cid:pants";
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_pants);
                            break;
                        
                        
                        case 5:   // bags field
                            item.bagsUri = imageUri;
                            item.bags = "cid:bags";
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_bags);
                            break;
                        
                default:
                  return;
              }

              picker.setImageUri(imageUri);
            } else if((requestCode & ImagePicker.CAPTURE_REQUEST_CODE) == ImagePicker.CAPTURE_REQUEST_CODE) {
				      switch (requestCode - ImagePicker.CAPTURE_REQUEST_CODE) {
                        
                        case 0:   // jackets field
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_jackets);
                            imageUri = fromFile(picker.getImageFile());
                        		item.jacketsUri = imageUri;
                            item.jackets = "cid:jackets";
                            break;
                        
                        
                        case 1:   // shirts field
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_shirts);
                            imageUri = fromFile(picker.getImageFile());
                        		item.shirtsUri = imageUri;
                            item.shirts = "cid:shirts";
                            break;
                        
                        
                        case 2:   // shoes field
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_shoes);
                            imageUri = fromFile(picker.getImageFile());
                        		item.shoesUri = imageUri;
                            item.shoes = "cid:shoes";
                            break;
                        
                        
                        case 3:   // assesories field
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_assesories);
                            imageUri = fromFile(picker.getImageFile());
                        		item.assesoriesUri = imageUri;
                            item.assesories = "cid:assesories";
                            break;
                        
                        
                        case 4:   // pants field
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_pants);
                            imageUri = fromFile(picker.getImageFile());
                        		item.pantsUri = imageUri;
                            item.pants = "cid:pants";
                            break;
                        
                        
                        case 5:   // bags field
                            picker = (ImagePicker) getView().findViewById(R.id.clothsds_bags);
                            imageUri = fromFile(picker.getImageFile());
                        		item.bagsUri = imageUri;
                            item.bags = "cid:bags";
                            break;
                        
                default:
                  return;
              }
              picker.setImageUri(imageUri);
            }
        }
    }
}

