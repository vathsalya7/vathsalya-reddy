
package com.ibm.mobileappbuilder.travel20161001062900.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ibm.mobileappbuilder.travel20161001062900.R;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.travel20161001062900.ds.ModeDSItem;
import com.ibm.mobileappbuilder.travel20161001062900.ds.ModeDS;

public class ModeoftravelDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<ModeDSItem> implements ShareBehavior.ShareListener  {

    private Datasource<ModeDSItem> datasource;
    public static ModeoftravelDetailFragment newInstance(Bundle args){
        ModeoftravelDetailFragment fr = new ModeoftravelDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public ModeoftravelDetailFragment(){
        super();
    }

    @Override
    public Datasource<ModeDSItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = ModeDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.modeoftraveldetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ModeDSItem item, View view) {
        
        ImageView view0 = (ImageView) view.findViewById(R.id.view0);
        URL view0Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.flight);
        if(view0Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view0.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view0Media.toExternalForm())
                                   .withTargetView(view0)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view0.setImageDrawable(null);
        }
        
        ImageView view1 = (ImageView) view.findViewById(R.id.view1);
        URL view1Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.train);
        if(view1Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view1.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view1Media.toExternalForm())
                                   .withTargetView(view1)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view1.setImageDrawable(null);
        }
        
        TextView view2 = (TextView) view.findViewById(R.id.view2);
        view2.setText("bus");
        
        
        ImageView view3 = (ImageView) view.findViewById(R.id.view3);
        URL view3Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.car);
        if(view3Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view3.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view3Media.toExternalForm())
                                   .withTargetView(view3)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view3.setImageDrawable(null);
        }
    }

    @Override
    protected void onShow(ModeDSItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }
    @Override
    public void onShare() {
        ModeDSItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, "bus");
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

