

package com.ibm.mobileappbuilder.travel20161001062900.ui;

import android.os.Bundle;

import com.ibm.mobileappbuilder.travel20161001062900.R;

import java.util.ArrayList;
import java.util.List;

import ibmmobileappbuilder.MenuItem;

import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.util.Constants;

/**
 * TravelFragment menu fragment.
 */
public class TravelFragment extends ibmmobileappbuilder.ui.MenuFragment {

    /**
     * Default constructor
     */
    public TravelFragment(){
        super();
    }

    // Factory method
    public static TravelFragment newInstance(Bundle args) {
        TravelFragment fragment = new TravelFragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
                }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("calender")
            .setIcon(R.drawable.png_calendaricon138)
            .setAction(new StartActivityAction(CalenderActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("mode of travel")
            .setIcon(R.drawable.jpg_timetotravel232147514516458)
            .setAction(new StartActivityAction(ModeoftravelActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("cloths")
            .setIcon(R.drawable.jpg_tnfgandesjacket415)
            .setAction(new StartActivityAction(ClothsActivity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_grid;
    }

    @Override
    public int getItemLayout() {
        return R.layout.travel_item;
    }
}

