package ibmmobileappbuilder.mvp.model;

public interface IdentifiableBean {

    String getIdentifiableId();

}
